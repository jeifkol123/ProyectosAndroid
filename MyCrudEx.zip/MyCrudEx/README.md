# MyCrudEx

MyCrudEx es una aplicación para Android de ejemplo en la cual están disponibles las operaciones CRUD (Agregar, Listar, Eliminar y Actualizar) usando una base de datos local en SQLite, el cual viene integrado por default en Android y nos facilita el manejo de información.

- Inicio: En la pantalla principal podemos ver las opciones Ver Elementos y Nuevo Elemento.
- Nuevo Elemento: Muestra un formulario para agregar elementos o contactos, contempla los campos Nombre, Apellido, Domicilio, Teléfono y Email al guardar el elemento se guarda en la base de datos local.
- Ver Elementos: Muestra la lista de todos los elementos o contactos que estén en la base de datos local y al seleccionar o darle tap a un elemento nos dirige a la pantalla de Editar Elemento.
- Editar Elemento: Muestra un formulacion para modificar el elemento seleccionado y también se encuentra la opción de eliminar Elemento.
- Eliminar Elemento: Muestra un dialogo para confirmar la eliminación y en caso de ser SI se elimina el elemento de la base de datos, cierra el formulacion de editar elemento y regresa a la pantalla de ver elementos.

Fuente: http://evilnapsis.com/2016/03/29/mycrudex-crud-sqlite-y-app-de-contactos-para-android/
Powered by Evilnapsis http://evilnapsis.com/
