# El Ahorcado
El popular juego del ahorcado (hangman) hecho en android studio.
Sencillo y con Sqlite para guardar las palabras y puntajes.
Tutorial y explicación: <a href="http://www.genesisvargasj.com/blog.php?post=37">http://www.genesisvargasj.com/blog.php?post=37</a>
<img src="http://www.genesisvargasj.com/assets/img/tuto38.png">
<img src="http://www.genesisvargasj.com/assets/img/tuto38-2.png">
